
import Vue from 'vue';
import Router from 'vue-router';

//组件模块
import Mycenter from './components/teacherpage/mycenter/MyCenter.vue';
import BasicInfo from './components/teacherpage/basicInfo/BasicInfo.vue';
import CourseManagement from './components/teacherpage/coursemanagement/CourseManagement.vue';

Vue.use(Router);

export default new Router({
    mode:"history",
    routes: [
        // { path: '/', name: 'home', component: Mycenter },
        { path: '/Home', name: 'home', component: Mycenter },
        { path: '/Mycenter', name: 'Mycenter', component: Mycenter },
        { path: '/BasicInfo', name: 'basic_info', component: BasicInfo},
        { path: '/CourseManagement', name: 'CourseManagement', component: CourseManagement},
    ]
})