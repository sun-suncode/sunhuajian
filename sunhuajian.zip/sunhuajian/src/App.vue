<template>
  <div id="app">
    <Header></Header>
    <PhoneLogin></PhoneLogin>
  </div>
</template>

<script>
import Header from "./components/teacherpage/common/Header.vue";
import PhoneLogin from "./components/teacherpage/login/PhoneLogin.vue";

export default {
  name: "App",
  components: {
    Header,
    PhoneLogin
  }
};
</script>

<style>

</style>
