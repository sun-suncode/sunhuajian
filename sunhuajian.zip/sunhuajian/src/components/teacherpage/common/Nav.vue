<template>
    <section id="nav">
      <div class="navigation_bar clearfix type_area">
        <router-link to="/Mycenter" class="my_center">My Center</router-link>
        <router-link to="/BasicInfo" class="navigation_bar_item" @click="addClass()">基本信息</router-link>
        <router-link to="/CourseManagement" class="navigation_bar_item" @click="addClass()">课程管理</router-link>
        <router-link to="/CourseManagement" class="navigation_bar_item" @click="addClass()">我的问答</router-link>
        <router-link to="/CourseManagement" class="navigation_bar_item" @click="addClass()">我的收入</router-link>
        <a href="javascript:;" class="add_course">+ 添加课程</a>
      </div>
       <router-view></router-view>
    </section>

   
</template>

<script>
export default {
  data() {
    return {
      number: 0,
      nav_list: ["基本信息", "课程管理", "我的问答", "我的收入"]
    };
  },
  methods: {
    change(index) {
      this.number = index;
    },
    addClass() {
      this.addClass("item_def");
    }
  }
};
</script>

<style>
/* 导航栏区域样式 */
#nav {
  background-color: #ffffff;
}

.navigation_bar {
  font-size: 18px;
  height: 120px;
  /* line-height: 120px; */
  position: relative;
  display: flex;
  align-items: center;
  /* background-color: red; */
}

.navigation_bar a {
  display: block;
  height: 55px;
  text-align: center;
  line-height: 55px;
  color: #333333;
  margin-right: 110px;
}

.navigation_bar .my_center {
  color: #00aaff;
  font-size: 30px;
  margin-right: 120px;
}

.navigation_bar_item:hover {
  color: #00aaff;
}
a.item_def {
  color: #00aaff;
  border-bottom: 1px solid #00aaff;
}

.navigation_bar .add_course {
  display: block;
  position: absolute;
  top: 39px;
  right: 0;

  width: 210px;
  height: 40px;
  line-height: 40px;
  text-align: center;
  color: #00aaff;
  border-radius: 25px;
  margin-right: 0;
  border: 1px solid gray;
}

.navigation_bar .add_course:hover {
  background-color: #00aaff;
  color: #fff;
}
</style>