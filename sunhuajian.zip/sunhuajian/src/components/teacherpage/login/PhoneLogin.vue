<template>
  <section>
    <div class="login_wrapper">
      <div class="teacher_bk">
        <img src alt />
      </div>
      <div class="login_form">
        <LoginForm></LoginForm>
      </div>
    </div>
  </section>
</template>

<script>
import LoginForm from "./LoginForm.vue";
export default {
  components: {
    LoginForm
  }
};
</script>

<style scoped lang="less">
.login_wrapper {
  margin-top: 2px;
  display: flex;
  align-items: center;
  background-color: #f9f9f9;
}
.teacher_bk {
  width: 680px;
  height: 840px;
  background-color: black;
}
.teacher_bk img {
  display: block;
  width: 100%;
  height: 100%;
}
.login_form {
  width: 845px;
  height: 605px;
  position: relative;
  right: 145px;
  border-radius: 5px;
  background-color: #ffffff;
}
</style>