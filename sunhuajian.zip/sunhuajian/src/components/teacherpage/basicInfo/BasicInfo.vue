
<template>
  <main>
    <section class="type_area flex">
      <BasicInfoLeft></BasicInfoLeft>
      <BasicInfoRight></BasicInfoRight>
    </section>
  </main>
</template>

<script>
import BasicInfoLeft from "./BasicInfoLeft";
import BasicInfoRight from "./BasicInfoRight";
export default {
  components: {
    BasicInfoLeft,
    BasicInfoRight
  }
};
</script>

<style>
main {
  padding: 40px 0;
  background-color: #f4f4f4;
}
.flex {
display: flex;
height: 780px;
justify-content: space-between;
}
</style>