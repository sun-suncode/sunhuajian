<template>
  <main>
    <section class="type_area flex">
      <CourseManagementLeft></CourseManagementLeft>
      <CourseManagementRight></CourseManagementRight>
    </section>
  </main>
</template>

<script>
import CourseManagementLeft from "./CourseManagementLeft.vue";
import CourseManagementRight from "./CourseManagementRight.vue";
export default {
  components: {
    CourseManagementLeft,
    CourseManagementRight
  }
};
</script>

<style scoped lang="less">
main {
  padding: 40px 0;
  background-color: #f4f4f4;
}
.flex {
display: flex;
height: 780px;
justify-content: space-between;
}
</style>