<template>
  <section class="course_management_left">
    <a href="javascript:;" class="head_photo">
      <img src="../../../assets/img/t1.jpg" alt />
      <p>编辑</p>
    </a>
    <a href="javascript:;" class="def">
      <i class="fa fa-file-text lo"></i>
      <span>我的课程</span>
    </a>
    <a href="javascript:;">
      <i class="fa fa-bullhorn lo"></i>
      <span>我的活动</span>
    </a>

    <!-- <a href="javascript:;" v-for="(item , index) in nav" :key="index" :class="{def:index==number}" @click="change(index)"><i class="fa lo" :class="[{fa-bullhorn:index==1},{}]"></i><span>我的活动</span></a> -->
  </section>
</template>

<script>
export default {
  data: function() {
    return {
      nav: ["我的课程", "我的活动"],
      number: 0
    };
  },
  methods: {
    change(index) {
      this.number = index;
    }
  }
};
</script>

<style scoped lang="less">
/* 课程管理页面左侧区域的样式 */
.course_management_left {
  width: 372px;
  text-align: center;
  background-color: #ffffff;
}
.course_management_left a {
  display: block;
  font-size: 20px;
  font-weight: bold;
  color: #666666;
}
.course_management_left a span {
  font-weight: bold;
}
.course_management_left a:hover {
  color: #00aaff;
}
.course_management_left .head_photo {
  width: 135px;
  height: 135px;
  margin: 65px auto;
  overflow: hidden;
  border-radius: 50%;
  position: relative;
}
.course_management_left .head_photo p {
  width: 100%;
  line-height: 30px;
  font-size: 14px;
  position: absolute;
  color: #ffffff;
  bottom: 0;
  left: 0;
  background-color: rgba(0, 0, 0, 0.4);
}
.course_management_left .head_photo p:hover {
  color: #00aaff;
}
.course_management_left .head_photo img {
  display: block;
  width: 100%;
  height: 100%;
}
.course_management_left a:nth-child(2) {
  margin: 70px 0 40px 0;
}
.course_management_left a.def {
  color: #00aaff;
}
.lo {
  margin-right: 15px;
}
</style>