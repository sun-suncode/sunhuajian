import Vue from 'vue';
import Router from 'vue-router';

//组件模块
import Login from './components/teacherpage/login/Login.vue';
import TeacherPage from './components/teacherpage/TeacherPage.vue';
import Mycenter from './components/teacherpage/mycenter/MyCenter.vue';
import BasicInfo from './components/teacherpage/basicInfo/BasicInfo.vue';
import CourseManagement from './components/teacherpage/coursemanagement/CourseManagement.vue';
import ByPhonelogin from './components/teacherpage/login/ByPhoneLogin.vue';
import ByPhoneSign from './components/teacherpage/login/ByPhoneLoginSign.vue';
import LoginForm from './components/teacherpage/login/LoginForm.vue';



Vue.use(Router);



/**
 * 重写路由的push方法
 */
const routerPush = Router.prototype.push
Router.prototype.push = function push(location) {
    return routerPush.call(this, location).catch(error => error)
}

export default new Router({
    mode: "history",
    routes: [
        {
            path: '', name: 'login', component: Login,
            children: [
                { path: '', name: 'LoginForm', component: LoginForm },
                { path: '/ByPhonelogin', name: 'ByPhonelogin', component: ByPhonelogin },
                { path: '/ByPhoneSign', name: 'ByPhoneSign', component: ByPhoneSign }
            ]
        },
        {
            path: '/', name: 'login', component: Login,
            children: [
                { path: '', name: 'LoginForm', component: LoginForm },
                { path: '/ByPhonelogin', name: 'ByPhonelogin', component: ByPhonelogin },
                { path: '/ByPhoneSign', name: 'ByPhoneSign', component: ByPhoneSign }
            ]
        },
        {
            path: '/Login', name: 'login', component: Login,
            children: [
                { path: '', name: 'LoginForm', component: LoginForm },
                { path: '/ByPhonelogin', name: 'ByPhonelogin', component: ByPhonelogin },
                { path: '/ByPhoneSign', name: 'ByPhoneSign', component: ByPhoneSign }
            ]

        },
        {
            path: 'TeacherPage', name: "TeacherPage", component: TeacherPage,
            children: [{ path: '/Mycenter', name: 'Mycenter', component: Mycenter },
            { path: '/BasicInfo', name: 'basic_info', component: BasicInfo },
            { path: '/CourseManagement', name: 'CourseManagement', component: CourseManagement }
            ]
        }
    ]
})