<template>
  <div class="my_courses_msg">
    <a href="javascript:;">
      <img :src="courses_lists.video" alt />
    </a>
    <div class="my_courses_msg_detail">
      <div class="my_courses_title">
        <h2>{{courses_lists.title}}</h2>
        <span class="status">{{courses_lists.status}}</span>
      </div>
      <p class="data_time">
        <span>上传时间:</span>
        <span class="data">{{courses_lists.data}}</span>
        <span>{{courses_lists.time}}</span>
      </p>
      <p class="people" v-if="tf">
        <span>
          <i class="fa fa-user-o"></i>128位学员
        </span>
        <span>
          <i class="fa fa-commenting ol"></i>18条评论
        </span>
      </p>
      <span class="price" :class="{mt:tf==true}">{{courses_lists.price}}</span>
    </div>
  </div>
</template>

<script>
export default {
  props: ["courses_lists","tf"],
  data() {
    return {
      my_courses: [
        {
          video: require("../../../assets/img/video1.jpg"),
          title: "显露你的实力 — 面试",
          status: "[进行中]",
          data: "3月23日",
          time: "15:43",
          price: "免费"
        },
        {
          video: require("../../../assets/img/video2.jpg"),
          title: "微信微博新媒体营销课程",
          status: "[已结束]",
          data: "3月23日",
          time: "15:43",
          price: "￥199元"
        }
      ]
    };
  }
};
</script>

<style scoped lang="less">
.my_courses_msg {
  height: 270px;
  box-sizing: border-box;
  padding: 60px 0px 50px 35px;
}
.my_courses_msg a {
  display: inline-block;
}
.my_courses_msg a img {
  display: block;
}
.my_courses .my_courses_msg:first-child {
  border-bottom: 1px solid #f3f3f3;
}
.my_courses_msg_detail {
  display: inline-block;
  vertical-align: top;
  margin-left: 35px;
}
.my_courses_title{
  margin-top: 10px;
}
.my_courses_title h2 {
  display: inline-block;
  font-weight: bold;
  font-size: 22px;
}
.status {
  display: inline-block;
  color: #00aaff;
  margin-left: 10px;
  font-size: 22px;
  font-weight: bold;
}
.data_time {
  font-size: 18px;
  margin: 20px 0;
  color: #cacaca;
}
.data {
  margin: 0 10px;
}
.ol {
  margin-left: 20px;
}
.people {
  font-size: 18px;
  color: #cacaca;
}

.price {
  display: inline-block;
  color: #00aaff;
  font-size: 22px;
  margin-left: 5px;
  font-weight: bold;
}
.mt{
  margin-top: 15px;
}

</style>