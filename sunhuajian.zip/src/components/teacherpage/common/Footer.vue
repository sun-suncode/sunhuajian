<template>
  <footer class="footer">
    <p>
      中国领先大学生成长平台
      <i></i>2016 e学聘
    </p>
    <p>ICP备16500007 | 联系我们 exuepin@exuepin.com | 关于我们</p>
  </footer>
</template>

<script>
export default {};
</script>

<style lang="less" scoped>
          /* 页面底部区域的样式 */
        .footer {
            background-color: #fff;
            color: gray;
            text-align: center;
            padding: 40px 0px;
            box-sizing: border-box;
        }

        .footer p:first-child {
            margin-bottom:15px;
        }
</style>