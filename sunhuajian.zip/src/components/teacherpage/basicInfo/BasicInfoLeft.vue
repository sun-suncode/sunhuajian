<template>
  <section class="basic_information_left">
    <a href="javascript:;">
      <img src="../../../assets/img/t1.jpg" alt />
    </a>
    <a href="javascript:;" class="basic_information_item def">
      <i class="fa fa-user-o"></i>我的信息
    </a>
    <a href="javascript:;" class="basic_information_item">
      <i class="fa fa-check-square"></i>认证信息
    </a>
    <a href="javascript:;" class="basic_information_item">
      <i class="fa fa-cog"></i>密码管理
    </a>
  </section>
</template>

<script>
export default {};
</script>

<style>
.basic_information_content .basic_information_left a {
  display: block;
  margin-top: 65px;
  font-size: 22px;
  color: #333333;
  font-weight: bold;
}

.basic_information_content .basic_information_left {
  float: left;
  width: 370px;
  height: 770px;
  margin-top: 40px;
  text-align: center;
  background-color: #fff;
}

.basic_information_content .basic_information_left img {
  display: block;
  width: 135px;
  height: 135px;
  margin: 60px auto;
  border-radius: 50%;
}
.basic_information_content .basic_information_left a:hover {
  color: #00aaff;
}
.basic_information_content .basic_information_left a.def {
  color: #00aaff;
}
.basic_information_content .basic_information_left a i {
  margin-right: 10px;
}
</style>