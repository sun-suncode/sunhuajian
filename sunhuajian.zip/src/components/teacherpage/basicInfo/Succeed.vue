<template>
  <section class="authinfo">
    <section class="auth_id">
      <Id :id_msg='{imgone:require("../../../assets/img/id1.jpg"),imgtwo:require("../../../assets/img/id2.jpg"),imgthree:require("../../../assets/img/id1.jpg"),status:"【已认证】"}'></Id>
    </section>
    <section class="auth_per">
      <PersonWrite></PersonWrite>
    </section>
  </section>
</template>

<script>
import Id from "./Id.vue";
import PersonWrite from "./Person.vue";

export default {
  components: {
    PersonWrite,
    Id
  }
};
</script>

<style lang="less" scoped>
</style>