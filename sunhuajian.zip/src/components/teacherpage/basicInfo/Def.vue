<template>
  <section class="authinfo">
    <section class="auth_id">
      <Id :id_msg='{imgone:require("../../../assets/img/id1.jpg"),imgtwo:require("../../../assets/img/id2.jpg"),imgthree:require("../../../assets/img/id1.jpg"),status:"【未认证】"}'></Id>
    </section>
    <section class="auth_per">
      <!-- <Person></Person> -->
      <router-view></router-view>
    </section>
  </section>
</template>

<script>
import Id from './Id.vue'
// import Person from'./Person.vue'

export default {
  components: {
    // Person,
    Id
  }
};
</script>

<style lang="less" scoped>

</style>