
<template>
  <main>
    <section  class="basic_information_content clearfix type_area">
      <BasicInfoLeft></BasicInfoLeft>
      <BasicInfoRight></BasicInfoRight>
    </section>
  </main>
</template>

<script>
import BasicInfoLeft from "./BasicInfoLeft";
import BasicInfoRight from "./BasicInfoRight";
export default {
  components: {
    BasicInfoLeft,
    BasicInfoRight
  }
};
</script>

<style>
main {
  background-color: #f4f4f4;
}
.flex {
display: flex;
height: 780px;
justify-content: space-between;
}
</style>