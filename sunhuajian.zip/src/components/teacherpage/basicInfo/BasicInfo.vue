
<template>
  <main>
    <section  class="type_area flex tb">
      <CommonLeft :msg='[{title:"我的信息",icon:"fa-user-o",class:"item_i"},{title:"认证信息",icon:"fa-check-square",class:"item_i"},{title:"密码管理",icon:"fa-cog",class:"item_i"}]'></CommonLeft>
      <BasicInfoRight></BasicInfoRight>
    </section>
  </main>
</template>

<script>
import CommonLeft from "../common/CommonLeft"
import BasicInfoRight from "./BasicInfoRight";
export default {
  components: {
    CommonLeft,
    BasicInfoRight
  }
};
</script>

<style lang="less" scoped>
main {
  background-color: #f4f4f4;
}
.flex {
display: flex;
/* height: 780px; */
justify-content: space-between;
}
</style>