<template>
  <main>
    <section class="type_area flex tb">
      <CourseManagementLeft></CourseManagementLeft>
      <CourseManagementRight></CourseManagementRight>
    </section>
  </main>
</template>

<script>
import CourseManagementLeft from "./CourseManagementLeft.vue";
import CourseManagementRight from "./CourseManagementRight.vue";
export default {
  components: {
    CourseManagementLeft,
    CourseManagementRight
  }
};
</script>

<style scoped lang="less">
main {
  background-color: #f4f4f4;
}
.flex {
display: flex;
height: 780px;
justify-content: space-between;
}
</style>