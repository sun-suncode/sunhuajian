<template>
  <main>
    <section class="type_area flex tb">
      <CommonLeft :msg='[{title:"我的课程",icon:"fa-file-text"},{title:"我的活动",icon:"fa-bullhorn"}]'></CommonLeft>
      <CourseManagementRight></CourseManagementRight>
    </section>
  </main>
</template>

<script>
import CommonLeft from "../common/CommonLeft";
import CourseManagementRight from "./CourseManagementRight.vue";
export default {
  components: {
    CommonLeft,
    CourseManagementRight
  }
};
</script>

<style scoped lang="less">
main {
  background-color: #f4f4f4;
}
.flex {
  display: flex;
  height: 780px;
  justify-content: space-between;
}
</style>