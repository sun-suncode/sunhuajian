<template>
  <section class="content_right">
    <MyCourses></MyCourses>
    <NewStudents></NewStudents>
  </section>
</template>

<script>
import NewStudents from "./NewStudents.vue";
import MyCourses from "./MyCourses.vue";
export default {
  props: ["user_course"],
  components: {
    MyCourses,
    NewStudents
  }
};
</script>

<style>

</style>