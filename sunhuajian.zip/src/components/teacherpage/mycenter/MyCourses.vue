<template>
  <section>
    <section id="my_courses">
      <h3>我上传的课程</h3>
      <p>
        <span class="my_courses_num">3</span>
        <span>个</span>
      </p>
      <p>
        <span>查看详情</span>
        <i class="fa fa-angle-right"></i>
      </p>
    </section>

    <section id="my_question_answer">
      <h3>我的问答</h3>
      <p>
        <span class="my_question_answer_num">3</span>
        <span>个</span>
      </p>
      <p>
        <span>查看详情</span>
        <i class="fa fa-angle-right"></i>
      </p>
    </section>
  </section>
</template>

<script>
export default {
  props: ["user_course"]
};
</script>

<style>
#my_courses,
#my_question_answer {
  display: inline-block;
  width: 450px;
  height: 345px;
  background-position: center;
  background-size: cover;
  padding: 40px 0 0 60px;
  box-sizing: border-box;
}

#my_courses {
    margin-right: 30px;
  background-image: url("../../../assets/img/bk1.jpg");
}
#my_question_answer{

  background-image: url("../../../assets/img/bk2.jpg");
}

.content_right h3 {
  font-size: 24px;
  margin-bottom: 45px;
  cursor: pointer;
}

.my_question_answer_num,
.my_courses_num {
  font-size: 34px;
  margin-right: 8px;
}

#my_courses p:nth-child(2),
#my_question_answer p:nth-child(2) {
  margin-bottom: 40px;
}

#my_courses p:nth-child(3),
#my_question_answer p:nth-child(3) {
  color: gray;
  cursor: pointer;
}
</style>